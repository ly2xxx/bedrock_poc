import pandas as pd

# Load the CSV file
df = pd.read_csv('SampleData/claimdata.csv')

# Print the first 5 rows
print(df.head())
